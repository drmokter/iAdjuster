package com.iadjuster.model;

public class InsuranceType {
	
	private String insType;
	
	private String insNote;

	public String getInsType() {
		return insType;
	}

	public void setInsType(String insType) {
		this.insType = insType;
	}

	public String getInsNote() {
		return insNote;
	}

	public void setInsNote(String insNote) {
		this.insNote = insNote;
	}





}
