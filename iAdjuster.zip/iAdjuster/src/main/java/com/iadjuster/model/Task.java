package com.iadjuster.model;

public class Task {
	
//	private long taskid;  //private Long  id;  will not work

	//private String taskdesc;
	private String taskdesc;
	
	private String tasknote;

//	
//	public long getTaskid() {
//		return taskid;
//	}
//
//	public void setTaskid(long taskid) {
//		this.taskid = taskid;
//	}

	public String getTaskdesc() {
		return taskdesc;
	}

	public void setTaskdesc(String taskdesc) {
		this.taskdesc = taskdesc;
	}

	public String getTasknote() {
		return tasknote;
	}

	public void setTasknote(String tasknote) {
		this.tasknote = tasknote;
	}



}
