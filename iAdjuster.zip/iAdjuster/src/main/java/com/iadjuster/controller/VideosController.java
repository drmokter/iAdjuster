package com.iadjuster.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class VideosController {

	@RequestMapping(value ="/videos")
	public String sayHello (Model model) {
		
		model.addAttribute("videos", "Hello to Videos World");
		
		return "videos";
	}
	
	
}
