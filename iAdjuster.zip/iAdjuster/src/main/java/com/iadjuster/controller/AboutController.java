package com.iadjuster.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Dr.Mokter
 *
 */
@Controller
public class AboutController {

	@RequestMapping(value ="/about")
	public String sayHello (Model model) {
		
	//	model.addAttribute("about", "Welcome to iAdjuster");
		
		return "about";
	}
	
}
