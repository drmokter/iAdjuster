package com.iadjuster.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MenuController {

	@RequestMapping(value ="/menu")
	public String sayHello (Model model) {
			
		return "menu";
	}


}
