package com.iadjuster.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


// http://stackoverflow.com/questions/8960886/how-to-display-text-and-images-both-in-same-jsp-page-in-easiest-way

@Controller
public class ImagesController {

	@RequestMapping(value ="/images")
	public String sayHello (Model model) {
		
	//	model.addAttribute("greeting", "Hello World");
		
		return "images";
	}
	
}
