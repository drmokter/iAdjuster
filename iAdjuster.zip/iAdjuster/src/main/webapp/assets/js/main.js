jQuery(document).ready(function($) {

	$('#msg').html("This is updated by jQuery")

});
