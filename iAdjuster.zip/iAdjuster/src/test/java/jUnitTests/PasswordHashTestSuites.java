package jUnitTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ PasswordHash_Admin.class, PasswordHash_M0kter.class, PasswordHash_Test.class })
public class PasswordHashTestSuites {

}
