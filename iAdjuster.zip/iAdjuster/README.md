iAdjuster spring_mvc_base
===============

Welcome to My iAdjuster

My iAdjuster is an amaging application for Insurance Property Claims Adjusters, Property Appraisers, or even Real Estate professionals. You won't know how you lived without it!FEATURES:* Import claims data from email* Provides mapping directions from current location to claim address* Call contact directly from Claim Contact section* Collect information for a property's Rooms, Roof Sections, and Contents * Automatically detect and store the pitch of a roof* Create drawings (useful for roof or room diagrams)* Attach photos or drawings directly to Claim * Export claim data to an auto-formatted email; and many more features.